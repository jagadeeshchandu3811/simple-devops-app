# Simple DevOps Node.js App

This is a simple Node.js application containerized with Docker and deployed via Jenkins CI/CD pipeline.

## Features

- Node.js Express server
- Jenkinsfile for CI/CD
- Dockerfile for containerization
- Test stage with simulated test